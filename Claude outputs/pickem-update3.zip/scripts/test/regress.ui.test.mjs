/* Regression tests for bugs that shipped and were fixed.

   Every case here is a defect that was live in production, that clicking
   around would not have surfaced, and that a plausible future edit could
   quietly reintroduce. A test named after the symptom is worth more than
   one named after the function, so they read as user complaints.

   Run:  node app-serve.mjs &   then   node regress.ui.test.mjs
*/
import { chromium } from 'playwright';

const BASE = 'http://127.0.0.1:8098';
let pass = 0, fail = 0; const fails = [];
const ok = (n, c, x = '') => { if (c) { pass++; console.log('  ok   ' + n); }
  else { fail++; fails.push(n + (x ? ' -> ' + x : '')); console.log('  FAIL ' + n + (x ? '  -> ' + x : '')); } };

const browser = await chromium.launch();

async function open(plan = {}) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const page = await ctx.newPage();
  await page.route('**/*', r => r.request().url().startsWith(BASE) ? r.continue() : r.abort());
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.request.post(BASE + '/__plan', { data: plan });
  await page.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(900);
  return { ctx, page, errors };
}

/* ------------------------------------------------------------------ */
console.log('\n1. Everyone called "Player" must not collapse into one row');
{
  /* THE BUG: PIN sign-in populates neither displayName nor email, so
     ensureMember() wrote the literal name "Player" for every member. The
     app then keyed players by NAME, so an entire pool of "Player" became a
     single bucket: five people, one row, everybody looking at one person's
     picks and one person's score. Keying by uid is the fix; this proves
     duplicate display names stay distinct. */
  const past0 = new Date(Date.now() - 40 * 864e5).toISOString();
  const { ctx, page, errors } = await open({
    members: ['Player', 'Player', 'Player', 'Player'], playerCount: 0,
    startISO: past0                     // ditto: the table needs scored weeks
  });
  await page.click('[data-tab="standings"]').catch(() => {});
  await page.waitForTimeout(400);
  const rows = await page.locator('#board .row').count();
  ok('four members with identical names render four standings rows', rows === 4, String(rows));
  ok('and no errors', errors.length === 0, errors[0] || '');
  await ctx.close();
}

/* ------------------------------------------------------------------ */
console.log('\n2. A name containing markup must not execute');
{
  /* THE BUG: member names went into innerHTML unescaped, and the rules let
     a member set their own name to anything. One member could therefore
     run script in every other member's session, on the origin holding
     their sign-in cookie. */
  const past = new Date(Date.now() - 40 * 864e5).toISOString();
  const { ctx, page, errors } = await open({
    members: ['Lee', '<img src=x onerror="window.__xss=1">'], playerCount: 0,
    startISO: past                      // finals exist, so the table renders
  });
  await page.click('[data-tab="standings"]').catch(() => {});
  await page.waitForTimeout(500);
  const fired = await page.evaluate(() => !!window.__xss);
  ok('markup in a display name does not execute', fired === false);
  const shown = await page.locator('#board').innerText();
  ok('and is shown as literal text instead', shown.includes('<img'), shown.slice(0, 80));
  ok('no errors', errors.length === 0, errors[0] || '');
  await ctx.close();
}

/* ------------------------------------------------------------------ */
console.log('\n3. "Final" must follow the recorded status, not the clock');
{
  /* THE BUG: isFinal() was kickoff + 3h20m. An overtime game, a weather
     delay or one missed scoring run flipped the app to Final while
     `winner` was still null — and a null winner matches nobody, so every
     player in the pool took a red miss on a game still being played, and
     the card printed the literal text "Final · null". */
  const { ctx, page, errors } = await open({ weeks: 2, gamesPerWeek: 4 });
  await page.waitForTimeout(500);
  const body = await page.locator('body').innerText();
  ok('the word "null" never reaches the screen', !/\bnull\b/.test(body),
     (body.match(/.{0,40}null.{0,40}/) || [''])[0]);
  ok('no errors', errors.length === 0, errors[0] || '');
  await ctx.close();
}

/* ------------------------------------------------------------------ */
console.log('\n4. A failed save must never say "Saved"');
{
  /* THE BUG: every pick write was `savePicks(...).catch(console.warn)`
     followed by an unconditional, synchronous flashSaved(). The green
     "Saved" was printed before the promise was even scheduled, so a denied
     write, a dead connection or a slow device clock all showed "Saved" and
     lost the picks. Someone could tap through sixteen games, be told
     sixteen times it saved, and go to bed with nothing written. */
  const { ctx, page, errors } = await open({ fail: { savePicks: true } });
  await page.waitForTimeout(400);
  const side = page.locator('#slate .side').first();
  if (await side.count()) {
    await side.click({ force: true }).catch(() => {});
    /* commitPicks() now retries once, silently, ~1.2s after the first
       rejection — see its own comment: a brand-new sign-in's Firestore
       connection can reject a write in its first second while it is
       still finishing its handshake, which is exactly what "picks didn't
       save" right after signing in, that then quietly stopped on its
       own, turned out to be. A permanently-failing save (this test) still
       ends up reported — just after that one retry, not before it. */
    await page.waitForTimeout(2200);
    const label = await page.locator('#toast').innerText().catch(() => '');
    ok('a rejected save does not report success', !/^saved$/i.test(label.trim()), label);
    ok('and says something is wrong instead',
       /not saved|didn.t save|check your connection|kicked off/i.test(label), label);
  } else {
    ok('a rejected save does not report success', false, 'no tappable game found');
    ok('and says something is wrong instead', false, 'no tappable game found');
  }
  ok('no errors', errors.length === 0, errors[0] || '');
  await ctx.close();
}

/* ------------------------------------------------------------------ */
console.log('\n5. Switching weeks must not leave listeners on the old one');
{
  /* THE BUG: watchWeek/watchRevealed were opened once, at boot, bound to
     the boot week — but their callbacks wrote into whatever week was on
     screen when they fired. Browsing ahead during a live Sunday let a
     week-5 score update overwrite the week-12 view: right header, wrong
     games, picks saved against game ids from another week. */
  const { ctx, page, errors } = await open({ weeks: 6, gamesPerWeek: 4 });
  await page.waitForTimeout(500);
  const before = await page.evaluate(() => window.__ps.calls('watchWeek'));
  const wk = page.locator('#weeks .wk').nth(3);
  if (await wk.count()) {
    await wk.click({ force: true }).catch(() => {});
    await page.waitForTimeout(800);
    const after = await page.evaluate(() => window.__ps.calls('watchWeek'));
    ok('changing week re-subscribes the live listeners', after > before,
       `${before} -> ${after}`);
  } else {
    ok('changing week re-subscribes the live listeners', false, 'no week strip');
  }
  ok('no errors', errors.length === 0, errors[0] || '');
  await ctx.close();
}

/* ------------------------------------------------------------------ */
console.log('\n6. The scoring mode shown must be the pool\'s real mode');
{
  /* THE BUG: the client read pools/{id}/config/scoring.history — a
     document nothing has ever written — while setup_season.py and
     score_week.py both use `scoringHistory` on the pool document. The read
     always missed and fell through to 'straight', so the confidence tray,
     the stake bars and every ranked point silently vanished for every
     player while the server scored the season in confidence.
     Separately, the Settings buttons had "Confidence" hardcoded as
     selected and nothing ever updated it. */
  const { ctx, page, errors } = await open({ mode: 'straight' });
  await page.waitForTimeout(500);
  await page.click('[data-tab="settings"]').catch(() => {});
  await page.waitForTimeout(400);
  const on = await page.locator('.mbtn.on').first().getAttribute('data-mode').catch(() => null);
  ok('a straight-up pool shows Straight-up selected', on === 'straight', String(on));
  ok('no errors', errors.length === 0, errors[0] || '');
  await ctx.close();
}

/* ------------------------------------------------------------------ */
console.log('\n7. A malformed game document must not kill the app');
{
  /* THE BUG: kickoff.toMillis() assumed every game document has a kickoff
     Timestamp. A scoring job writing by a reconstructed id could create a
     partial document holding only scores, and one of those threw inside
     loadSeason() — which is not wrapped in optional() — so a single bad
     row took the whole app down for everyone with "We couldn't load your
     week." */
  const { ctx, page, errors } = await open({ badTeam: true });
  await page.waitForTimeout(700);
  const visible = await page.locator('#slate .card').count();
  ok('an unknown team abbreviation still renders the slate', visible > 0, String(visible));
  ok('no errors', errors.length === 0, errors[0] || '');
  await ctx.close();
}

/* ------------------------------------------------------------------ */
console.log('\n8. A notification switch that did not save must not look on');
{
  /* THE BUG: the toggle wrote fire-and-forget with an empty catch. A
     denied or dropped write left the switch on, localStorage agreeing,
     and the roster — the only thing remind.py and worker/live.js read —
     never updated. The player is then certain they turned on the last
     call reminder, and it simply never comes. */
  const { ctx, page, errors } = await open({ fail: { upsertRoster: true } });
  await page.click('[data-tab="settings"]').catch(() => {});
  await page.waitForTimeout(400);
  const sw = page.locator('#prefs [data-pref]').first();
  if (await sw.count()) {
    const before = await sw.getAttribute('class');
    await sw.click({ force: true }).catch(() => {});
    await page.waitForTimeout(700);
    const after = await page.locator('#prefs [data-pref]').first().getAttribute('class');
    ok('a rejected write reverts the switch', before === after, `${before} -> ${after}`);
    const t = await page.locator('#toast').innerText().catch(() => '');
    ok('and says so out loud', /save|connection/i.test(t), t);
  } else {
    ok('a rejected write reverts the switch', false, 'no preference switches found');
    ok('and says so out loud', false, 'no preference switches found');
  }
  ok('the switches are reachable by keyboard',
     (await page.locator('#prefs button[role="switch"]').count()) > 0);
  await ctx.close();
}

/* ------------------------------------------------------------------ */
console.log('\n9. Nobody leads a week in which nobody has scored');
{
  /* THE BUG: the Grid's first row got the gold `lead` class
     unconditionally, so the moment the first game merely kicked off —
     before any result existed — the table sat on all-zero points with a
     crowned leader, who is really just whoever sorts first. The
     Standings tab already guarded this; the Grid did not. */
  const soon = new Date(Date.now() - 30 * 60 * 1000).toISOString();
  const { ctx, page, errors } = await open(
    { weeks: 1, gamesPerWeek: 4, startISO: soon, playerCount: 6 });
  await page.click('[data-tab="grid"]').catch(() => {});
  await page.waitForTimeout(700);
  const verdict = await page.evaluate(() => {
    const lead = document.querySelectorAll('#gridBody tbody tr.lead').length;
    if (!lead) return 'none';
    const pts = [...document.querySelectorAll('#gridBody tbody tr td.tot')]
      .map(td => parseInt(td.textContent, 10) || 0);
    return pts.some(p => p > 0) ? 'someone scored' : 'crowned at zero';
  });
  ok('no gold row while every score is zero', verdict !== 'crowned at zero', verdict);
  ok('no errors', errors.length === 0, errors[0] || '');
  await ctx.close();
}

/* ------------------------------------------------------------------ */
console.log('\n10. "Show me the walkthrough again" must not skip to the last page');
{
  /* THE BUG: replayOnboarding() looked for the one screen flagged
     `howto` — the "Six rules" recap, which is also the LAST screen
     before "Let's play" — so tapping this in Settings for someone
     already signed in landed one tap from the end and skipped every
     other page of the tour (install, alerts) that the function's own
     comment said it was never supposed to skip. Only the two sign-in
     screens (name/email, the code) are meant to be skipped for someone
     already in. */
  const { ctx, page, errors } = await open({});
  await page.waitForTimeout(700);
  await page.click('[data-tab="help"]').catch(() => {});
  await page.waitForTimeout(200);
  await page.click('#hpReplay', { force: true }).catch(() => {});
  await page.waitForTimeout(300);
  const heading = await page.locator('#obBody').innerText().catch(() => '');
  ok('replay does not open on the final "Six rules" recap screen',
     !/Six rules/i.test(heading), heading.slice(0, 60));
  ok('and does not open on a sign-in screen either',
     !/What do we call you|Check your inbox/i.test(heading), heading.slice(0, 60));
  ok('no errors', errors.length === 0, errors[0] || '');
  await ctx.close();
}

/* ------------------------------------------------------------------ */
console.log('\n11. A live player must never be shown the invented demo season');
{
  /* THE BUG, reported twice as "it is caching an old version" and chased
     twice in the wrong place, because from outside that is exactly what
     it looks like.

     index.html builds a mock season at module scope — shuffled matchups
     from slateFor(), kickoffs placed at W1OFF minute-offsets from
     Date.now() — and that loop ran unconditionally, DEMO or not. The
     first EIGHT week-1 offsets are negative, so isLive() (which is only
     `Date.now() >= g.kick`) was true for half of week 1 the instant the
     page parsed. Every player opening the app saw teams who are not
     playing each other, half of them reading "IN PROGRESS · LOCKED", in
     a week that has not started — until loadSeason() finished its
     network round trips and swapped the real schedule in underneath.

     Tapping to week 2 and back appeared to "fix" it, which is what sent
     two separate investigations looking at caching, listeners and
     Firestore consistency. It fixed nothing: it just forced a render
     against data that had since become real.

     What this asserts is the one thing that actually matters — that
     nothing on screen came from the generator. Real games here carry
     Firestore's document ids (`2026_W1_AWAY_HOME` shape, per
     import_schedule.py and app-serve.mjs); generated ones are `w1g0`,
     `w1g1`... So a single `w<digits>g<digits>` anywhere in the rendered
     slate means the mockup reached a live player's screen. */
  /* THE WINDOW IS THE WHOLE TEST, and the first version of this missed it.

     Written the obvious way — load the app, look at the slate — this
     passes with the bug fully present, because against a local stub
     loadSeason() resolves in milliseconds and the mock season is
     overwritten before any assertion runs. Confirmed by putting the bug
     back and watching the suite stay green, which is the only reason
     this comment exists.

     The defect lives in the gap between page parse and the schedule
     arriving. On a phone on 4G that gap is seconds long; here it has to
     be created deliberately, by holding getAllWeeks open. Everything
     asserted below is read DURING that gap.

     ASSERTED ON #countdown, deliberately. tick() runs on a one-second
     interval from module scope — before any sign-in, before boot's
     network chain, regardless of auth — and writes the next kickoff into
     that header straight out of WEEKS. So with the bug present it names a
     fabricated matchup within a second of page load, with nothing else
     required to reproduce it. That is also the exact artifact the player
     photographed: their header read "BRONCOS @ SEAHAWKS · 2M 26S", which
     is SLATES[1][9] = ['DEN','SEA'] at W1OFF[9] = +9 minutes from load.

     Checking the slate instead does NOT work here, and the first two
     attempts at this test proved it: nothing paints #slate until boot
     finishes, so against a local stub the assertion runs after the real
     schedule has already replaced the mockup and passes with the bug
     fully in place. Both earlier versions stayed green when the fix was
     reverted. This one does not. */
  const b = await open({ signedOut: true, delay: { getAllWeeks: 4000 } });
  await b.page.waitForTimeout(1600);         // tick() has run; schedule has not landed

  /* One assertion, because only one discriminates. Matching on team
     nicknames looks more specific and is worthless: SLATES[1] covers all
     32 clubs, so any nickname list either matches the real schedule too
     or misses most of the mock one — the first draft of this let
     "JAGUARS @ RAIDERS · 33S" through. With no schedule loaded there is
     nothing legitimate to count down to, so the header naming ANY
     matchup at this moment means the mock season is live on screen. */
  const head = await b.page.locator('#countdown').innerText().catch(() => '');
  ok('the countdown names no game at all while the schedule is still loading',
     head.trim() === '' || !/@/.test(head), head.slice(0, 60));

  const leaked = await b.page.evaluate(() =>
    [...document.querySelectorAll('#slate [data-game]')]
      .map(el => el.getAttribute('data-game'))
      .filter(id => /^w\d+g\d+$/.test(id)));
  ok('no generated game ids are painted while the real schedule loads',
     leaked.length === 0, leaked.slice(0, 3).join(', '));
  ok('no errors', b.errors.length === 0, b.errors[0] || '');
  await b.ctx.close();

  // ...and once a real schedule does land, everything renders normally.
  const c = await open({ weeks: 3 });
  await c.page.waitForTimeout(1200);
  ok('the real games render once the schedule lands',
     (await c.page.locator('#slate [data-game]').count()) > 0);
  ok('and the countdown then names a real one',
     /\d/.test(await c.page.locator('#countdown').innerText().catch(() => '')));
  await c.ctx.close();
}

/* ------------------------------------------------------------------ */
console.log('\n12. The Home Screen prompt must fit the browser it is standing in');
{
  /* THE COMPLAINT that produced this screen: the first person other than
     the owner to be sent the link gave up at "tap the three dots, tap
     Share, scroll, Add to Home Screen" — four steps, described for a
     browser they were not even using, before they had any reason to care.

     Two things have to hold and neither is visible from reading the code.
     The steps must match the ACTUAL browser (Safari puts Share in the
     toolbar; Chrome, Edge and Firefox on iOS each bury it behind their
     own menu first), and there must always be a way straight past it,
     because everything except the kickoff alert works fine in a tab and a
     forced install wall in front of a stranger is how you lose them.

     iPhone cannot install from a button — Apple ships no API for it — so
     accurate instructions are the whole of what is possible there, which
     is exactly why getting them per-browser is worth a test. */
  const UA = {
    safari: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 '
          + '(KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',
    edge:   'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 '
          + '(KHTML, like Gecko) Version/17.5 EdgiOS/122.0 Mobile/15E148 Safari/604.1',
    laptop: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
          + '(KHTML, like Gecko) Chrome/124.0 Safari/537.36',
  };
  const openUA = async ua => {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, userAgent: ua });
    const page = await ctx.newPage();
    await page.route('**/*', r => r.request().url().startsWith(BASE) ? r.continue() : r.abort());
    const errors = []; page.on('pageerror', e => errors.push(String(e)));
    await page.request.post(BASE + '/__plan', { data: { signedOut: true } });
    await page.goto(BASE + '/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(900);
    return { ctx, page, errors };
  };

  const saf = await openUA(UA.safari);
  ok('an iPhone lands on the Home Screen prompt before signing in',
     /Home Screen/i.test(await saf.page.locator('#obBody').innerText().catch(() => '')));
  ok('and is always offered a way straight past it',
     await saf.page.locator('#obSkip').isVisible().catch(() => false));
  await saf.page.click('#obGo').catch(() => {});
  await saf.page.waitForTimeout(400);
  const safSteps = await saf.page.locator('.ob-steps').innerText().catch(() => '');
  ok('Safari is pointed at the Share button in its own toolbar',
     /bottom of the screen/i.test(safSteps) && !/⋯/.test(safSteps), safSteps.slice(0, 70));
  ok('no errors', saf.errors.length === 0, saf.errors[0] || '');
  await saf.ctx.close();

  const edg = await openUA(UA.edge);
  await edg.page.click('#obGo').catch(() => {});
  await edg.page.waitForTimeout(400);
  const edgSteps = await edg.page.locator('.ob-steps').innerText().catch(() => '');
  ok('Edge on iOS is told about its own menu first, then Share',
     /⋯/.test(edgSteps) && /Share/i.test(edgSteps), edgSteps.slice(0, 70));
  ok('the two browsers are not handed identical instructions',
     edgSteps.trim() !== safSteps.trim());
  await edg.ctx.close();

  const dsk = await openUA(UA.laptop);
  ok('a laptop is never shown a Home Screen prompt',
     !/Home Screen/i.test(await dsk.page.locator('#obBody').innerText().catch(() => '')));
  ok('no errors on desktop', dsk.errors.length === 0, dsk.errors[0] || '');
  await dsk.ctx.close();
}

/* NOT COVERED HERE, deliberately, and worth knowing about.

   weekSum() now prefers the server's figure for any week that is not the
   one on screen, and the live client calculation for the week that is —
   which is what stops the Standings tab freezing at the Sunday-9pm
   scoring run all the way through Sunday Night Football, without also
   zeroing a week the moment you browse away from it.

   A test for that was written and then deleted: this harness's PS stub
   returns a fabricated standings record for every week that holds a
   final game, so both the old and the new code passed it. A test that
   cannot fail is worse than no test — it is a green tick that means
   nothing — and this file exists precisely because two of the earlier
   assertions in this project encoded broken behaviour as correct.

   Covering it properly needs the stub to model a week that has finals
   but has NOT been scored yet. That is the next thing to add here.

   The residual limitation, stated plainly: loadWeek() keeps only one
   week of everyone's picks in memory, so a week that has finals and no
   server record yet still shows zero for other players once you browse
   away from it. Scoring runs three times a week, so that window is
   real but short. Fixing it properly means caching revealed picks per
   week rather than per load. */

/* ------------------------------------------------------------------ */
await browser.close();
console.log(`\n${pass} passed, ${fail} failed`);
if (fails.length) { console.log('FAILURES:'); fails.forEach(f => console.log('  - ' + f)); }
process.exit(fail ? 1 : 0);
